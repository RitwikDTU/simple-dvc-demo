# -*- coding: utf-8 -*-
"""
Created on Thu Apr 15 22:35:08 2021

@author: ritwi
"""

from setuptools import setup, find_packages

setup(
      name="src",
      version="0.0.1",
      description="Its a wine Q package",
      author="Ritwik",
      packages=find_packages(),
      license="MIT"
      )